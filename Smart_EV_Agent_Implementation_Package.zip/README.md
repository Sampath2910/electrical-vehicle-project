# Smart EV Agent Package

Start with `SMART_EV_PROJECT_AGENT_SPEC.md`.

The package also includes:
- the earlier product/architecture blueprint PDF and DOCX
- architecture diagram
- sitemap
- QR/RFID payment flow diagram

The specification is the implementation contract. The other documents are supporting visual/product context.
